-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 24, 2018 at 02:42 PM
-- Server version: 5.7.24-0ubuntu0.18.04.1
-- PHP Version: 7.2.10-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `notes`
--

-- --------------------------------------------------------

--
-- Table structure for table `best_songs`
--

CREATE TABLE `best_songs` (
  `id_best_songs` int(10) UNSIGNED NOT NULL,
  `title` text NOT NULL,
  `rating` tinyint(3) UNSIGNED DEFAULT NULL,
  `tags` text NOT NULL,
  `youtube_url` text NOT NULL,
  `data` blob,
  `creation_date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_edit` datetime DEFAULT NULL,
  `state` tinyint(3) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `best_songs`
--

INSERT INTO `best_songs` (`id_best_songs`, `title`, `rating`, `tags`, `youtube_url`, `data`, `creation_date_time`, `last_edit`, `state`) VALUES
(1, 'Red Hot Chili Peppers - Aeroplane', 2, 'Drum', 'https://www.youtube.com/watch?v=vV8IAOojoAA', NULL, '2018-01-19 09:29:05', '2018-10-24 14:11:54', 1),
(2, 'Ben Harper - With My Own Two Hands', 0, '', 'https://www.youtube.com/watch?v=aEnfy9qfdaU', NULL, '2018-01-19 09:29:05', '2018-10-22 07:40:54', 1),
(3, 'Elton John - Tiny Dancer', 0, '\'70, drum', 'https://www.youtube.com/watch?v=yYcyacLRPNs', NULL, '2018-01-19 09:29:05', '2018-10-23 07:56:49', 1),
(4, 'Bon Jovi - You Give Love A Bad Name', 0, 'drum', 'https://www.youtube.com/watch?v=KrZHPOeOxQQ', NULL, '2018-01-19 09:29:05', '2018-10-22 14:44:32', 1),
(5, 'Lenny Kravitz - Are You Gonna Go My Way', 0, 'drum', 'https://www.youtube.com/watch?v=8LhCd1W2V0Q', NULL, '2018-01-19 09:29:05', '2018-10-22 14:52:06', 1),
(6, 'Deep Purple - Highway Star', 2, 'drum, \'70', 'https://www.youtube.com/watch?v=Wr9ie2J2690', NULL, '2018-01-19 09:29:05', '2018-10-22 14:46:54', 1),
(7, 'Muse - Starlight', 0, '', 'https://www.youtube.com/watch?v=Pgum6OT_VH8', NULL, '2018-01-19 09:29:05', '2018-10-22 14:54:29', 1),
(8, 'Manu Chao - Bongo Bong', 0, '', 'https://www.youtube.com/watch?v=vJMLJVha5sw', NULL, '2018-01-19 09:29:05', '2018-10-22 14:53:59', 1),
(9, 'Violent Femmes - Blister In The Sun', 0, '', 'https://www.youtube.com/watch?v=JE-dqW4uBEE', NULL, '2018-01-19 09:29:05', '2018-10-22 15:00:59', 1),
(10, 'Bon Jovi - Always', NULL, '', 'https://www.youtube.com/watch?v=9BMwcO6_hyA', NULL, '2018-01-19 09:29:05', '2018-10-24 07:07:18', 1),
(11, 'London Grammar - ...is a beautiful...', 0, '', 'https://www.youtube.com/watch?v=UPcPtd3k-Qg', '', '2018-01-19 09:29:05', NULL, 1),
(12, 'Groove Armada - My Friend', 0, '', 'https://www.youtube.com/watch?v=JxohJX9ElpE', '', '2018-01-19 09:29:05', NULL, 1),
(13, 'Breeders - Cannonball', 0, '', 'https://www.youtube.com/watch?v=fxvkI9MTQw4', '', '2018-01-19 09:29:05', NULL, 1),
(14, 'Who - My Generation', 0, '', 'https://www.youtube.com/watch?v=qN5zw04WxCc', '', '2018-01-19 09:29:05', NULL, 1),
(15, 'GINO PAOLI - UNA LUNGA STORIA D\'AMORE', NULL, 'drum, \'60', 'https://www.youtube.com/watch?v=WyRsj-DIZ5I', '', '2018-01-19 09:29:05', NULL, 1),
(16, 'Nelly Furtado - Turn Off The Light', 0, '', 'https://www.youtube.com/watch?v=kOL7aeIDruA', NULL, '2018-01-19 09:29:05', '2018-10-22 14:54:37', 1),
(17, 'Emerson, Lake & Palmer - Lucky Man', 0, '', 'https://www.youtube.com/watch?v=oK0fhSr-ARY', NULL, '2018-01-19 09:29:05', '2018-10-23 08:00:52', 1),
(18, 'SPIN DOCTORS - TWO PRINCES', 3, 'drum', 'https://www.youtube.com/watch?v=wsdy_rct6uo', NULL, '2018-01-19 09:29:05', '2018-10-23 21:32:41', 1),
(19, 'BRUCE SPRINGSTEEN - I\'M ON FIRE', 0, '', 'https://www.youtube.com/watch?v=xzQvGz6_fvA', NULL, '2018-01-19 09:29:05', '2018-10-19 07:47:33', 1),
(20, 'The White Stripes - Seven Nation Army', 0, 'drum', 'https://www.youtube.com/watch?v=0J2QdDbelmY', NULL, '2018-01-19 09:29:05', '2018-10-22 14:59:24', 1),
(21, 'Korn - Falling Away From Me', 0, '', 'https://www.youtube.com/watch?v=2s3iGpDqQpQ', NULL, '2018-01-19 09:29:05', '2018-10-22 14:51:57', 1),
(22, 'Sex Pistols - Anarchy In The U.K.', 0, '', 'https://www.youtube.com/watch?v=qbmWs6Jf5dc', NULL, '2018-01-19 09:29:05', '2018-10-22 14:57:37', 1),
(23, 'BILL WITHERS - AIN\'T NO SUNSHINE', 0, '', 'https://www.youtube.com/watch?v=tIdIqbv7SPo', NULL, '2018-01-19 09:29:05', '2018-10-19 07:48:55', 1),
(24, 'Foo Fighters - Learn To Fly', 2, '', 'https://www.youtube.com/watch?v=1VQ_3sBZEm0', NULL, '2018-01-19 09:29:05', '2018-10-19 07:52:33', 1),
(25, 'Iggy Pop - Lust For Life', 0, '', 'https://www.youtube.com/watch?v=HuBU3pzy7is', NULL, '2018-01-19 09:29:05', '2018-10-22 14:51:14', 1),
(26, 'Everything But The Girl - Missing', 5, '', 'https://www.youtube.com/watch?v=Q4sPkS8b62Q', '', '2018-01-19 09:29:05', NULL, 1),
(27, 'Tiromancino - Due Destini', 0, '', 'https://www.youtube.com/watch?v=-d1FhhG7YSI', NULL, '2018-01-19 09:29:05', '2018-10-22 14:59:50', 1),
(28, 'Ramones - Sheena Is A Punk Rocker', 0, '', 'https://www.youtube.com/watch?v=y3TQnMtUYwU', NULL, '2018-01-19 09:29:05', '2018-10-22 14:56:32', 1),
(29, 'Placebo - Every You Every Me', 0, '', 'https://www.youtube.com/watch?v=OMaycNcPsHI', NULL, '2018-01-19 09:29:05', '2018-10-22 14:55:43', 1),
(30, 'Placebo - Every You Every Me', 0, '', 'https://www.youtube.com/watch?v=OMaycNcPsHI', NULL, '2018-01-19 09:29:17', '2018-10-23 21:36:43', 0),
(31, 'Joy Division - Love Will Tear Us Apart', 0, '', 'https://www.youtube.com/watch?v=zuuObGsB0No', NULL, '2018-01-19 09:57:59', '2018-10-22 14:51:39', 1),
(32, 'The Clash - London Calling', 4, '', 'https://www.youtube.com/watch?v=EfK-WX2pa8c', NULL, '2018-01-19 11:01:50', '2018-10-22 07:39:58', 1),
(33, 'Aerosmith - Crazy', 1, '', 'https://www.youtube.com/watch?v=NMNgbISmF4I', NULL, '2018-01-19 15:01:42', '2018-10-22 07:40:43', 1),
(34, 'Extreme - More Than Words', 0, '', 'https://www.youtube.com/watch?v=UrIiLvg58SY', NULL, '2018-01-22 12:44:23', '2018-10-22 14:47:41', 1),
(35, 'Tears For Fears - Sowing The Seeds Of Love', 0, '', 'https://www.youtube.com/watch?v=VAtGOESO7W8', NULL, '2018-01-23 09:55:34', '2018-10-22 14:58:30', 1),
(36, 'Eric Clapton - Layla', 0, '', 'https://www.youtube.com/watch?v=0WUdlaLWSVM', NULL, '2018-01-23 10:30:29', '2018-10-22 14:47:30', 1),
(37, 'Police - Roxanne', 0, '', 'https://www.youtube.com/watch?v=3T1c7GkzRQQ', NULL, '2018-01-23 11:29:57', '2018-10-22 14:56:01', 1),
(38, 'The Verve - The Drugs Don\'t Work', 0, '', 'https://www.youtube.com/watch?v=ToQ0n3itoII', NULL, '2018-01-23 17:26:32', '2018-10-22 14:59:11', 1),
(39, 'Edie Brickell, New Bohemians - What I Am', 0, '', '', NULL, '2018-01-24 14:14:01', '2018-10-23 07:56:57', 0),
(40, 'Gorillaz - Feel Good Inc', 0, '', 'https://www.youtube.com/watch?v=HyHNuVaZJ-k', NULL, '2018-01-25 11:09:11', '2018-10-22 14:48:26', 1),
(41, 'Nothing But Thieves - Particles', 0, '', 'https://www.youtube.com/watch?v=jG_luFPxIHk', NULL, '2018-01-25 14:08:31', '2018-10-22 14:55:00', 1),
(42, 'Jefferson Airplane - White Rabbit', 0, '\'70', 'https://www.youtube.com/watch?v=WANNqr-vcx0', NULL, '2018-01-25 14:13:12', '2018-10-22 14:51:28', 1),
(43, 'Bon Jovi - Livin On A Prayer', 0, '', 'https://www.youtube.com/watch?v=lDK9QqIzhwk', NULL, '2018-01-27 15:19:57', '2018-10-22 14:44:21', 1),
(44, 'Violent Femmes - Blister in the sun', NULL, '', '', '', '2018-01-27 15:45:57', '2018-10-23 21:29:51', 0),
(45, 'Easy Star All-Stars - Let Down (feat. Toots & The Maytals)', 0, '', 'https://www.youtube.com/watch?v=ChHRkfo2Gss', NULL, '2018-02-06 15:48:16', '2018-10-22 14:47:08', 1),
(46, 'Sinéad O\'Connor - Nothing Compares 2 U', 4, '\'90', 'https://www.youtube.com/watch?v=0-EF60neguk', NULL, '2018-02-13 13:55:57', '2018-10-22 14:57:57', 1),
(47, 'Lenny Kravitz - Rock And Roll Is Dead', 0, 'drum', 'https://www.youtube.com/watch?v=yw8_5OYKQNA', NULL, '2018-02-21 10:58:37', '2018-10-22 14:52:29', 1),
(48, 'The Roots - The Seed', 0, '', 'https://www.youtube.com/watch?v=ojC0mg2hJCc', NULL, '2018-02-22 09:34:57', '2018-10-22 14:58:55', 1),
(49, 'Gotye - Somebody That I Used To Know', 3, '', 'https://www.youtube.com/watch?v=6YzGOq42zLk', NULL, '2018-03-05 09:16:21', '2018-10-22 14:49:23', 1),
(50, 'Lenny Kravitz - If You Can\'t Say No', 3, '', 'https://www.youtube.com/watch?v=uxm11aSfSR8', NULL, '2018-03-05 09:16:59', '2018-10-22 14:52:19', 1),
(51, 'Mia Martini - Minuetto', 4, 'Italian', 'https://www.youtube.com/watch?v=3W75gZHjB0c', NULL, '2018-03-05 09:37:01', '2018-10-22 14:54:21', 1),
(52, 'Gemelli Diversi - Un Attimo Ancora', 0, '\'90', 'https://www.youtube.com/watch?v=XheV-5NKjUg', NULL, '2018-03-07 10:05:02', '2018-10-22 14:48:11', 1),
(53, 'Rilo Kiley - Hail To Whatever You Found In The Sunlight That Surrounds You', 2, '', 'https://www.youtube.com/watch?v=fbfmwKM2zFg', NULL, '2018-03-07 17:38:15', '2018-10-23 21:35:44', 1),
(54, 'Shivaree - Goodnight Moon', 2, '', 'https://www.youtube.com/watch?v=tCXeYq6KYZc', NULL, '2018-03-08 12:33:31', '2018-10-23 21:33:26', 1),
(55, 'Patty Griffin - Goodbye', 0, '', 'https://www.youtube.com/watch?v=spnBPl7Xpko', NULL, '2018-03-09 09:15:25', '2018-10-22 14:55:22', 1),
(56, 'R.E.M. - Drive', 3, '', 'https://www.youtube.com/watch?v=-UE7tXDKIus', NULL, '2018-03-12 17:41:11', '2018-10-23 13:50:47', 1),
(57, 'Focus - Hocus Pocus', 0, '', 'https://www.youtube.com/watch?v=MV0F_XiR48Q', NULL, '2018-03-13 09:35:07', '2018-10-22 14:50:41', 1),
(58, 'radio.xspf', NULL, '<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<playlist xmlns=\"http://xspf.org/ns/0/\" xmlns:vlc=\"http://www.videolan.org/vlc/playlist/ns/0/\" version=\"1\">\n	<title>Playlist</title>\n	<trackList>\n		<track>\n			<location>http://shoutcast.rtl.it:3020/</location>\n			<title>RTL best</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>0</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.rtl.it:3030/</location>\n			<title>RTL ItalianStyle</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>1</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.rtl.it:3040/</location>\n			<title>RTL Groove</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>2</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.rtl.it:3070/</location>\n			<title>RTL Lounge</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>3</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.rtl.it:3060/</location>\n			<title>RTL Radiofreccia</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>4</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.rtl.it:3030/stream/1/</location>\n			<title>Radio Zeta L’Italiana</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>5</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://wma08.fluidstream.net:4610/</location>\n			<title>Radio Kiss Kiss</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>6</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://ice07.fluidstream.net:8080/KissKiss.mp3</location>\n			<title>Radio Kiss Kiss</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>7</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://wma07.fluidstream.net:3616/;stream.nsv</location>\n			<title>Radio Kiss Kiss Italia</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>8</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://ice08.fluidstream.net/KKNapoli.aac</location>\n			<title>Radio Kiss Kiss Napoli</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>9</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://www.rds.it:8000/stream</location>\n			<title>RDS</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>10</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://radiodeejay-lh.akamaihd.net/i/RadioDeejay_Live_1@189857/master.m3u8</location>\n			<title>Radio Deejay</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>11</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icecast.unitedradio.it/r101</location>\n			<title>R101 Diretta</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>12</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icecast.unitedradio.it/Virgin.mp3</location>\n			<title>Virgin Radio</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>13</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://radiocapital-lh.akamaihd.net/i/RadioCapital_Live_1@196312/master.m3u8</location>\n			<title>Radio Capital</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>14</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/1.mp3</location>\n			<title>Rai Radio 1</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>15</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/2.mp3</location>\n			<title>Rai Radio 2</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>16</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/3.mp3</location>\n			<title>Rai Radio 3</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>17</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/4.mp3</location>\n			<title>Rai Radio 4 Light</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>18</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/5.mp3</location>\n			<title>Rai Radio 5 Classica</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>19</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it:80/9.mp3</location>\n			<title>Rai Radio 6 Teca</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>20</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it:80/10.mp3</location>\n			<title>Rai Radio 7 Live</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>21</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it:80/11.mp3</location>\n			<title>Rai Radio 8 Opera</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>22</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/6.mp3</location>\n			<title>Rai IsoRadio</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>23</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/7.mp3</location>\n			<title>Rai GrParlamento</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>24</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icecast.105.net/105.mp3</location>\n			<title>Radio 105</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>25</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://edge.radiomontecarlo.net/RMC.mp3</location>\n			<title>RMC Radio Monte Carlo</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>26</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://edge.radiomontecarlo.net/MC2.mp3</location>\n			<title>RMC2 Radio Monte Carlo 2</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>27</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://radiom2o-lh.akamaihd.net/i/RadioM2o_Live_1@42518/master.m3u8</location>\n			<title>Radio m2o</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>28</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.radio24.it:8000/listen.pls</location>\n			<title>Radio 24</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>29</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair18.xdevel.com:8212/</location>\n			<title>Radio Marte</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>30</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://wma02.fluidstream.net:5010/</location>\n			<title>Radio Ibiza</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>31</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair11.xdevel.com:9990/</location>\n			<title>Radionorba</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>32</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair7.xdevel.com:8738/</location>\n			<title>Radionorba Music &amp; Sport</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>33</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair18.xdevel.com:8152</location>\n			<title>Radio Subasio</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>34</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair11.xdevel.com:8050</location>\n			<title>Radio Subasio +</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>35</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair11.xdevel.com:8002</location>\n			<title>Radio Amore Campania</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>36</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://nr9.newradio.it:9029</location>\n			<title>Radio Cuore</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>37</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://sr9.inmystream.info:8006</location>\n			<title>RIN Radio Italia Network</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>38</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://176.31.254.217:8030/</location>\n			<title>Radio RCS l’Onda Veronese</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>39</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair11.xdevel.com:8024</location>\n			<title>LifeGate Radio</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>40</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://5.63.145.172:7203/</location>\n			<title>Radio Studio Delta</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>41</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://nr5.newradio.it:8545/stream.mp3</location>\n			<title>Radio Sportiva</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>42</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://91.121.38.216:8060/</location>\n			<title>Studioradio – The Vintage Station</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>43</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://ice.studiopiu.net/rete.aac</location>\n			<title>Radio Studio Più</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>44</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://stream.rcdc.it:8000/</location>\n			<title>Radio Città Del Capo</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>45</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://comodino.org:8001/rcf.ogg</location>\n			<title>Radio Città Fujiko</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>46</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://stream-dc1.radioparadise.com:80/aac-128</location>\n			<title>Radio Paradise - DC1</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>47</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://stream-tx3.radioparadise.com:80/aac-128</location>\n			<title>Radio Paradise - TX3</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>48</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://stream-eu1.radioparadise.com:80/aac-128</location>\n			<title>Radiu Paradise - EU1</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>49</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://stream-uk1.radioparadise.com:80/aac-128</location>\n			<title>Radiu Paradise - UK1</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>50</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>		\n	</trackList>\n	<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n			<vlc:item tid=\"0\"/>\n			<vlc:item tid=\"1\"/>\n			<vlc:item tid=\"2\"/>\n			<vlc:item tid=\"3\"/>\n			<vlc:item tid=\"4\"/>\n			<vlc:item tid=\"5\"/>\n			<vlc:item tid=\"6\"/>\n			<vlc:item tid=\"7\"/>\n			<vlc:item tid=\"8\"/>\n			<vlc:item tid=\"9\"/>\n			<vlc:item tid=\"10\"/>\n			<vlc:item tid=\"11\"/>\n			<vlc:item tid=\"12\"/>\n			<vlc:item tid=\"13\"/>\n			<vlc:item tid=\"14\"/>\n			<vlc:item tid=\"15\"/>\n			<vlc:item tid=\"16\"/>\n			<vlc:item tid=\"17\"/>\n			<vlc:item tid=\"18\"/>\n			<vlc:item tid=\"19\"/>\n			<vlc:item tid=\"20\"/>\n			<vlc:item tid=\"21\"/>\n			<vlc:item tid=\"22\"/>\n			<vlc:item tid=\"23\"/>\n			<vlc:item tid=\"24\"/>\n			<vlc:item tid=\"25\"/>\n			<vlc:item tid=\"26\"/>\n			<vlc:item tid=\"27\"/>\n			<vlc:item tid=\"28\"/>\n			<vlc:item tid=\"29\"/>\n			<vlc:item tid=\"30\"/>\n			<vlc:item tid=\"31\"/>\n			<vlc:item tid=\"32\"/>\n			<vlc:item tid=\"33\"/>\n			<vlc:item tid=\"34\"/>\n			<vlc:item tid=\"35\"/>\n			<vlc:item tid=\"36\"/>\n			<vlc:item tid=\"37\"/>\n			<vlc:item tid=\"38\"/>\n			<vlc:item tid=\"39\"/>\n			<vlc:item tid=\"40\"/>\n			<vlc:item tid=\"41\"/>\n			<vlc:item tid=\"42\"/>\n			<vlc:item tid=\"43\"/>\n			<vlc:item tid=\"44\"/>\n			<vlc:item tid=\"45\"/>\n			<vlc:item tid=\"46\"/>\n			<vlc:item tid=\"47\"/>\n			<vlc:item tid=\"48\"/>\n			<vlc:item tid=\"49\"/>\n			<vlc:item tid=\"50\"/>			\n	</extension>\n</playlist>\n\n', '', '', '2018-03-14 09:03:38', NULL, 0),
(59, 'Bruce Springsteen - Streets of Philadelphia', 3, '', 'https://www.youtube.com/watch?v=4z2DtNW79sQ', '', '2018-03-19 10:49:04', NULL, 1),
(60, 'The Connells - \'74-\'75', 3, '', 'https://www.youtube.com/watch?v=l-ITv4OBV9c', NULL, '2018-03-20 09:09:44', '2018-10-22 07:39:57', 1),
(61, 'Procol Harum - A Whiter Shade Of Pale', 4, '', 'https://www.youtube.com/watch?v=Mb3iPP-tHdA', NULL, '2018-03-20 09:35:52', '2018-10-22 14:56:07', 1),
(62, 'Crash Test Dummies - Mmm', 2, '', 'https://www.youtube.com/watch?v=eTeg1txDv8w', NULL, '2018-03-20 10:01:33', '2018-10-22 14:45:27', 1),
(63, 'Florence & The Machine - Heartlines', 3, '', 'https://www.youtube.com/watch?v=bZKgLyGjcd4', NULL, '2018-03-22 15:13:47', '2018-10-23 08:23:21', 1),
(64, 'Tears For Fears, Oleta Adams - Woman In Chains', 2, '', 'https://www.youtube.com/watch?v=O5-c79LQ3aM', NULL, '2018-04-03 16:21:34', '2018-10-23 21:25:27', 1),
(65, 'Rosie Carney - WINTER', 0, '', 'https://www.youtube.com/watch?v=yz5EqFmQ5io', NULL, '2018-04-06 14:25:25', '2018-10-23 21:35:34', 1),
(66, 'Madonna - Papa Don\'t Preach', NULL, '', '', NULL, '2018-04-09 09:07:48', '2018-10-23 21:22:48', 1),
(67, 'Queen - Somebody To Love', 3, '', 'https://www.youtube.com/watch?v=kijpcUv-b8M', '', '2018-04-09 09:12:02', NULL, 1),
(68, 'Antonio Vivaldi - The 4 Seasons: Summer', 2, '', 'https://www.youtube.com/watch?v=KY1p-FmjT1M', '', '2018-04-09 11:36:31', NULL, 1),
(69, 'The Decemberists - Carolina Low', 4, '', 'https://www.youtube.com/watch?v=-fZwphTpJWI', '', '2018-04-09 12:25:46', '2018-10-23 21:25:46', 0),
(70, 'Patty Smith - Because The Night', 2, '', 'https://www.youtube.com/watch?v=c_BcivBprM0', NULL, '2018-04-10 10:55:24', '2018-10-22 14:55:33', 1),
(71, 'Nada - Amore Disperato', 2, '', 'https://www.youtube.com/watch?v=vk69MwiRhLE', '', '2018-04-11 11:50:15', NULL, 1),
(72, 'John Coltrane - Theme For Ernie', NULL, '', '', '', '2018-04-11 14:22:21', NULL, 1),
(73, 'Stone Temple Pilots - Big Empty', 0, '', 'https://www.youtube.com/watch?v=GqyposaQWnI', NULL, '2018-04-11 15:01:05', '2018-10-22 14:58:21', 1),
(74, 'R.e.m. - Losing My Religion', 4, '', 'https://www.youtube.com/watch?v=xwtdhWltSIg', '', '2018-04-12 09:08:52', NULL, 1),
(75, 'Chuck Berry - No Particular Place To Go', 2, '', 'https://www.youtube.com/watch?v=t6OS_ItMGpc', '', '2018-04-12 10:29:21', NULL, 1),
(76, 'Madonna - Who\'s That Girl', 0, '', 'https://www.youtube.com/watch?v=Zi8U2S-2-Cc', NULL, '2018-04-12 10:53:42', '2018-10-22 14:53:48', 1),
(77, 'Culture Club, Boy George - Do You Really Want To Hurt Me', 2, '', 'https://www.youtube.com/watch?v=2nXGPZaTKik', '', '2018-04-12 14:14:22', NULL, 1),
(78, 'Everything But The Girl - Missing', 4, '', 'https://www.youtube.com/watch?v=Q4sPkS8b62Q', '', '2018-04-12 15:58:36', '2018-10-23 08:02:46', 0),
(79, 'Cyndi Lauper - Time After Time', 3, '', 'https://www.youtube.com/watch?v=VdQY7BusJNU', '', '2018-04-13 11:42:38', NULL, 1),
(80, 'Bill Withers - Ain\'t No Sunshine', 0, '', 'https://www.youtube.com/watch?v=tIdIqbv7SPo', NULL, '2018-04-23 14:12:16', '2018-10-19 07:48:50', 1),
(81, 'Roy Rogers - I\'m With You', 0, '', 'https://www.youtube.com/watch?v=omaOPkGgJSo', NULL, '2018-04-27 09:07:42', '2018-10-23 21:34:56', 1),
(82, 'Agnes Obel - Riverside', 0, '', 'https://www.youtube.com/watch?v=vjncyiuwwXQ', NULL, '2018-05-09 10:54:11', '2018-10-22 14:44:03', 1),
(83, 'Agnes Obel - Riverside', 0, '', 'https://www.youtube.com/watch?v=vjncyiuwwXQ', NULL, '2018-05-09 11:45:38', '2018-10-19 07:50:38', 1),
(84, 'Ray LaMontagne - Be Here Now', 0, '', 'https://www.youtube.com/watch?v=8hEk-k68jZc', NULL, '2018-05-11 13:57:45', '2018-10-22 14:56:48', 1),
(85, 'Steely Dan - Do It Again', 0, '', 'https://www.youtube.com/watch?v=Oxi1cmG_5pc', NULL, '2018-05-14 09:06:26', '2018-10-22 14:58:14', 1),
(86, 'Vienna Teng - Augustine', 0, '', 'https://www.youtube.com/watch?v=J_eJePIJV2U', NULL, '2018-05-17 10:15:42', '2018-10-22 15:00:35', 1),
(87, 'Breeders - 02 - cannonball', 0, '', 'https://www.youtube.com/watch?v=fxvkI9MTQw4', NULL, '2018-05-21 10:57:13', '2018-10-22 14:44:44', 1),
(88, 'Lorde - Royals', 0, '', 'https://www.youtube.com/watch?v=nlcIKh6sBtc', NULL, '2018-05-22 10:16:42', '2018-10-22 14:52:45', 1),
(89, 'The Drums - Let\'s Go Surfing', 0, '', 'https://www.youtube.com/watch?v=VkQrJ3SVXko', NULL, '2018-05-23 17:51:10', '2018-10-22 14:58:47', 1),
(90, 'The Strokes - Last Nite', 0, '', 'https://www.youtube.com/watch?v=TOypSnKFHrE', NULL, '2018-05-23 17:53:52', '2018-10-22 14:59:01', 1),
(91, 'A-Punk - Vampire Weekend', 0, '', 'https://www.youtube.com/watch?v=_XC2mqcMMGQ', NULL, '2018-05-24 09:27:38', '2018-10-19 07:51:13', 1),
(92, 'Joy Division - She\'s Lost Control', NULL, '', 'https://www.youtube.com/watch?v=ZGMDBppWBOo', '', '2018-05-24 11:43:01', NULL, 1),
(93, 'Death Cab For Cutie - I Will Follow You Into The Dark', 0, '', 'https://www.youtube.com/watch?v=NDHY1D0tKRA', NULL, '2018-05-24 13:51:49', '2018-10-22 14:46:10', 1),
(94, 'Hysteria - Muse', 0, '', 'https://www.youtube.com/watch?v=3dm_5qWWDV8', NULL, '2018-05-24 15:24:31', '2018-10-22 14:50:49', 1),
(95, 'Time Is Running Out - Muse', 0, '', 'https://www.youtube.com/watch?v=O2IuJPh6h_A', NULL, '2018-05-24 16:22:20', '2018-10-22 14:59:28', 1),
(96, 'Nothing Else Matter - Metallica', 0, '', 'https://www.youtube.com/watch?v=tAGnKpE4NCI', NULL, '2018-05-25 14:06:42', '2018-10-22 14:55:06', 1),
(97, 'Santana - Samba Pa Ti', 0, '', 'https://www.youtube.com/watch?v=j5AUm_xaE9A', NULL, '2018-06-12 12:19:12', '2018-10-22 14:57:06', 1),
(98, 'Mario Venuti - Fortuna', 0, '', 'https://www.youtube.com/watch?v=i37Hb_THoUk', NULL, '2018-07-14 12:53:52', '2018-10-22 14:54:10', 1),
(99, 'Alicia Keys - You Don\'t Know My Name', 2, '', 'https://www.youtube.com/watch?v=_ST6ZRbhGiA', NULL, '2018-07-20 09:20:15', '2018-10-18 10:30:16', 1),
(100, 'Cure - Boys Don\'t Cry', 0, '', 'https://www.youtube.com/watch?v=ryImbOTDXe8', NULL, '2018-07-20 12:38:07', '2018-10-22 14:45:51', 1),
(101, 'Belly - Feed The Tree', 0, '', 'https://www.youtube.com/watch?v=RQJjUbMrt8w', NULL, '2018-07-23 09:01:06', '2018-10-19 07:50:12', 1),
(102, 'Black Sabbath - Iron Man', 0, '', 'https://www.youtube.com/watch?v=8aQRq9hhekA', NULL, '2018-07-30 08:42:37', '2018-10-19 07:48:39', 1),
(103, 'Weezer - Beverly Hills', 0, '', 'https://www.youtube.com/watch?v=HL_WvOly7mY', NULL, '2018-07-30 09:19:20', '2018-10-22 15:01:13', 1),
(104, 'Fatboy Slim - Right Here, Right Now', 0, '', 'https://www.youtube.com/watch?v=F7jSp2xmmEE', NULL, '2018-07-30 10:19:55', '2018-10-22 14:47:58', 1),
(105, 'Madonna - Like A Prayer', 4, '', 'https://www.youtube.com/watch?v=79fzeNUqQbQ', NULL, '2018-07-31 15:34:30', '2018-10-22 14:53:37', 1),
(106, 'The Sundays - Here\'s Where The Story Ends', 0, '', 'https://www.youtube.com/watch?v=FHsip5xOenQ', NULL, '2018-08-01 08:54:34', '2018-10-22 14:59:15', 1),
(107, 'The Audreys - Long Ride', 0, '', 'https://www.youtube.com/watch?v=OH15BOxJFno', NULL, '2018-08-01 13:58:00', '2018-10-22 07:39:38', 1),
(108, 'Focus - Hocus Pocus', 0, '', 'https://www.youtube.com/watch?v=MV0F_XiR48Q', NULL, '2018-08-03 16:05:22', '2018-10-23 08:02:55', 0),
(109, 'The Dandy Warhols - Bohemian Like You', 2, '', 'https://www.youtube.com/watch?v=CU3mc0yvRNk', NULL, '2018-08-06 09:00:54', '2018-10-22 14:58:39', 1),
(110, 'Miles Davis - \'Round Midnight', NULL, '', '', '', '2018-08-06 10:28:45', NULL, 1),
(111, 'Cloud Cult - When Water Comes to Life', 0, '', 'https://www.youtube.com/watch?v=VYyHAXZKaPQ', NULL, '2018-08-08 15:52:47', '2018-10-22 14:45:19', 1),
(112, 'Sivert Høyem - Prisoner of the Road', 3, '', 'https://www.youtube.com/watch?v=KTmVTiRnlFA', NULL, '2018-08-27 07:23:10', '2018-10-23 21:33:05', 1),
(113, 'The Decemberists - Carolina Low', 4, '', 'https://www.youtube.com/watch?v=-fZwphTpJWI', '', '2018-08-28 12:04:09', NULL, 1),
(114, 'The Decemberists - Till the Water Is All Long Gone', 1, '', 'https://www.youtube.com/watch?v=x2ZS92TVWPA', '', '2018-08-28 12:09:13', NULL, 1),
(115, 'Lana Del Rey - West Coast', 2, '', 'https://www.youtube.com/watch?v=oKxuiw3iMBE', '', '2018-09-05 09:46:24', NULL, 1),
(116, 'Frida Snell - Bullet With Butterfly Wings', 1, '', 'https://www.youtube.com/watch?v=75lN73ujgBU', '', '2018-09-11 07:44:58', NULL, 1),
(117, 'Nick Drake - Cello Song', 3, '', 'https://www.youtube.com/watch?v=h4y8WGOJu_c', '', '2018-09-11 08:35:15', NULL, 1),
(118, 'Heather Nova - Island', 2, '', 'https://www.youtube.com/watch?v=rCEI0JxPOtQ', '', '2018-09-11 13:03:21', NULL, 1),
(119, 'Everything But The Girl - Missing', NULL, '', 'https://www.youtube.com/watch?v=Q4sPkS8b62Q\r\n', '', '2018-09-13 14:42:33', NULL, 1),
(120, 'UB40 - Rat In My Kitchen', 0, '', 'https://www.youtube.com/watch?v=dHwPYze5M9s', NULL, '2018-09-26 12:44:47', '2018-10-22 15:00:16', 1),
(121, 'UB40 - Red Red Wine', 0, '', 'https://www.youtube.com/watch?v=zXt56MB-3vc', NULL, '2018-09-26 12:44:58', '2018-10-22 15:00:22', 1),
(122, 'UB40 - Kingstone town', 0, '', 'https://www.youtube.com/watch?v=ZBfSu4nGDfk', NULL, '2018-09-26 12:51:05', '2018-10-22 14:59:56', 1),
(123, 'Ramones - Do You Wanna Dance?', 2, '', 'https://www.youtube.com/watch?v=lu_lQpnHDhQ', '', '2018-09-27 07:32:07', NULL, 1),
(124, 'Finley Quaye - Even after all', 4, '', 'https://www.youtube.com/watch?v=214cQIpcCIc', '', '2018-09-28 14:01:29', NULL, 1),
(125, 'Samuele Bersani - Spaccacuore', 3, '', 'https://www.youtube.com/watch?v=NOvFQlh9ZKU', '', '2018-10-01 13:47:28', NULL, 1),
(126, 'Ben Harper - When It\'s Good', 0, '', 'https://www.youtube.com/watch?v=BLZZMdP-UFI', NULL, '2018-10-03 08:00:57', '2018-10-19 07:50:07', 1),
(127, 'Family Of The Year - Hero', 2, '', 'https://www.youtube.com/watch?v=mHeK0Cwr9sg', '', '2018-10-03 15:13:53', NULL, 1),
(128, 'Bobby Mcferrin - Don\'t Worry, Be Happy', 0, '', 'https://www.youtube.com/watch?v=d-diB65scQU', NULL, '2018-10-09 07:11:58', '2018-10-19 07:48:27', 1),
(129, 'Nine Million Bicycles - Nine Million Bicycles', 2, '', 'https://www.youtube.com/watch?v=eHQG6-DojVw', NULL, '2018-10-09 07:16:47', '2018-10-22 14:54:50', 1),
(130, 'Edie Brickell & New Bohemians - What I am', 3, '', 'https://www.youtube.com/watch?v=tDl3bdE3YQA', '', '2018-10-09 08:38:15', NULL, 1),
(131, 'Francesco De Gregori - Rimmel', 3, '', 'https://www.youtube.com/watch?v=Ydo-yfPze30', '', '2018-10-09 10:39:01', NULL, 1),
(132, 'Marilyn Manson - Sweet Dreams (Are Made Of This)', 3, '', 'https://www.youtube.com/watch?v=QUvVdTlA23w', '', '2018-10-09 20:12:51', NULL, 1),
(133, 'Sunken - Swoon', 1, '', 'https://www.youtube.com/watch?v=a_p94KrfiM4', '', '2018-10-10 07:07:44', NULL, 1),
(134, 'First Aid Kit - Tender Offerings', 2, '', 'https://www.youtube.com/watch?v=ofY6nuoKJD4', '', '2018-10-10 09:03:27', NULL, 1),
(135, 'Snowbird - Heart Of The Woods', 0, 'Italiano', 'https://www.youtube.com/watch?v=GrpiwcJ01Us', NULL, '2018-10-12 12:39:35', '2018-10-24 14:39:48', 1),
(136, 'Sergio Cammariere - Malgrado Poi', 3, '', 'https://www.youtube.com/watch?v=kwQUWemZCyA', '', '2018-10-15 07:05:46', NULL, 1),
(137, 'Bat For Lashes - All Your Gold', 1, '', 'https://www.youtube.com/watch?v=EXK0Ejzin4c', '', '2018-10-15 08:55:10', NULL, 1),
(138, 'Lamb - Gorecki', 0, '', 'https://www.youtube.com/watch?v=tSRYvYN1ayw', '', '2018-10-15 09:34:54', NULL, 1),
(139, 'Given To Fly', 0, '', 'https://www.youtube.com/watch?v=satY_ofTNo4', '', '2018-10-16 07:34:01', NULL, 1),
(140, 'Rapture', 0, '', 'https://www.youtube.com/watch?v=pHCdS7O248g', '', '2018-10-16 09:57:43', NULL, 1),
(141, 'The Doors - People Are Strange', 3, '', 'https://www.youtube.com/watch?v=GJY8jJkDoMY', '', '2018-10-16 09:58:06', NULL, 1),
(142, 'U2 - Sunday Bloody Sunday', 3, '', 'https://www.youtube.com/watch?v=EM4vblG6BVQ', '', '2018-10-17 12:10:19', NULL, 1),
(143, 'Nirvana - Smells Like Teen Spirits', 4, '', 'https://www.youtube.com/watch?v=hTWKbfoikeg', NULL, '2018-10-17 15:45:42', '2018-10-23 21:37:55', 1),
(144, 'Fiorella Mannoia - Sally', 2, 'Italiano', 'https://www.youtube.com/watch?v=YLB8vycVrj0', NULL, '2018-10-18 07:19:02', '2018-10-22 14:50:36', 1),
(145, 'Clash - London calling', 3, '', 'https://www.youtube.com/watch?v=EfK-WX2pa8c', NULL, '2018-10-18 08:10:50', '2018-10-22 14:45:06', 1),
(146, 'Niccolò Fabi - Lasciarsi un giorno a Roma', 3, 'Italiano', 'https://www.youtube.com/watch?v=lBgPpzEs7KI', NULL, '2018-10-18 08:16:58', '2018-10-22 14:54:43', 1),
(147, 'Sting - Love Is The Seventh Wave', 2, '', 'https://www.youtube.com/watch?v=uXZistami3c', NULL, '2018-10-22 07:38:24', '2018-10-22 07:39:04', 1),
(148, ' - Ain\'t No Sunshine', 0, '', 'https://www.youtube.com/watch?v=fIdnpjceg9A', NULL, '2018-10-23 06:58:43', '2018-10-23 07:56:22', 0),
(149, 'Lou Reed - Perfect Day', 3, '', 'https://www.youtube.com/watch?v=QYEC4TZsy-Y', NULL, '2018-10-24 07:18:15', '2018-10-24 07:19:12', 1),
(150, 'Eagles - Hotel California', 0, '', 'https://www.youtube.com/watch?v=EqPtz5qN7HM', NULL, '2018-10-24 08:05:39', NULL, 1),
(151, 'Rilo Kiley - Wires and Waves', 0, '', 'https://www.youtube.com/watch?v=TlP9Opw8ZHg', NULL, '2018-10-24 10:05:39', NULL, 1),
(152, 'Tracy Chapman - Fast Car', 0, '', 'https://www.youtube.com/watch?v=AIOAlaACuv4', NULL, '2018-10-24 10:28:49', NULL, 1),
(153, 'Storm Large  - Where is my Mind', 0, '', 'https://www.youtube.com/watch?v=QzpLa6Y4cnk', NULL, '2018-10-24 10:34:31', NULL, 1),
(154, 'Laura Marling - Rambling Man', 0, '', 'https://www.youtube.com/watch?v=JvwWzcLfH-k', NULL, '2018-10-24 14:14:17', NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `best_songs`
--
ALTER TABLE `best_songs`
  ADD PRIMARY KEY (`id_best_songs`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `best_songs`
--
ALTER TABLE `best_songs`
  MODIFY `id_best_songs` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=155;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
