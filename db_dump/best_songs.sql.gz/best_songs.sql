-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 17, 2018 at 09:30 AM
-- Server version: 5.7.23-0ubuntu0.18.04.1
-- PHP Version: 7.2.10-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `notes`
--

-- --------------------------------------------------------

--
-- Table structure for table `best_songs`
--

CREATE TABLE `best_songs` (
  `id_best_songs` int(10) UNSIGNED NOT NULL,
  `title` text NOT NULL,
  `rating` tinyint(3) UNSIGNED DEFAULT NULL,
  `tags` text NOT NULL,
  `youtube_url` text NOT NULL,
  `creation_date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` tinyint(3) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `best_songs`
--

INSERT INTO `best_songs` (`id_best_songs`, `title`, `rating`, `tags`, `youtube_url`, `creation_date_time`, `state`) VALUES
(1, 'RED HOT CHILI PEPPERS - AEROPLANE', NULL, 'drum', 'https://www.youtube.com/watch?v=vV8IAOojoAA', '2018-01-19 09:29:05', 1),
(2, 'BEN HARPER - WITH MY OWN TWO HANDS', NULL, '', 'https://www.youtube.com/watch?v=aEnfy9qfdaU', '2018-01-19 09:29:05', 1),
(3, 'ELTON JOHN - TINY DANCER', NULL, '\'70, drum', 'https://www.youtube.com/watch?v=yYcyacLRPNs', '2018-01-19 09:29:05', 1),
(4, 'BON JOVI - YOU GIVE LOVE A BAD NAME', NULL, 'drum', 'https://www.youtube.com/watch?v=KrZHPOeOxQQ', '2018-01-19 09:29:05', 1),
(5, 'LENNY KRAVITZ - ARE YOU GONNA GO MY WAY', NULL, 'drum', 'https://www.youtube.com/watch?v=8LhCd1W2V0Q', '2018-01-19 09:29:05', 1),
(6, 'DEEP PURPLE - HIGHWAY STAR', NULL, 'drum, \'70', 'https://www.youtube.com/watch?v=Wr9ie2J2690', '2018-01-19 09:29:05', 1),
(7, 'MUSE - STARLIGHT', NULL, '', 'https://www.youtube.com/watch?v=Pgum6OT_VH8', '2018-01-19 09:29:05', 1),
(8, 'MANU CHAO - BONGO BONG', NULL, '', 'https://www.youtube.com/watch?v=vJMLJVha5sw', '2018-01-19 09:29:05', 1),
(9, 'VIOLENT FEMMES - BLISTER IN THE SUN', NULL, '', 'https://www.youtube.com/watch?v=JE-dqW4uBEE', '2018-01-19 09:29:05', 1),
(10, 'BON JOVI - ALWAYS', NULL, '', 'https://www.youtube.com/watch?v=9BMwcO6_hyA', '2018-01-19 09:29:05', 1),
(11, 'london grammar - ...is a beautiful...', NULL, '', 'https://www.youtube.com/watch?v=UPcPtd3k-Qg', '2018-01-19 09:29:05', 1),
(12, 'GROOVE ARMADA - MY FRIEND', NULL, '', 'https://www.youtube.com/watch?v=JxohJX9ElpE', '2018-01-19 09:29:05', 1),
(13, 'BREEDERS~CANNONBALL~LAST SPLASH~1993', NULL, '', 'https://www.youtube.com/watch?v=fxvkI9MTQw4', '2018-01-19 09:29:05', 1),
(14, 'WHO~MY GENERATION~THE WHO SINGS MY GENERATION~1965', NULL, '', 'https://www.youtube.com/watch?v=594WLzzb3JI', '2018-01-19 09:29:05', 1),
(15, 'GINO PAOLI - UNA LUNGA STORIA D\'AMORE', NULL, 'drum, \'60', 'https://www.youtube.com/watch?v=WyRsj-DIZ5I', '2018-01-19 09:29:05', 1),
(16, 'NELLY FURTADO - TURN OFF THE LIGHT', NULL, '', 'https://www.youtube.com/watch?v=kOL7aeIDruA', '2018-01-19 09:29:05', 1),
(17, 'EMERSON LAKE ', NULL, '', 'https://www.youtube.com/watch?v=89g1P_J40JA', '2018-01-19 09:29:05', 1),
(18, 'SPIN DOCTORS - TWO PRINCES', NULL, 'drum', 'https://www.youtube.com/watch?v=wsdy_rct6uo', '2018-01-19 09:29:05', 1),
(19, 'BRUCE SPRINGSTEEN - I\'M ON FIRE', NULL, '', '', '2018-01-19 09:29:05', 1),
(20, 'THE WHITE STRIPES - SEVEN NATION ARMY', NULL, 'drum', '', '2018-01-19 09:29:05', 1),
(21, 'KORN - FALLING AWAY FROM ME', NULL, '', '', '2018-01-19 09:29:05', 1),
(22, 'SEX PISTOLS - ANARCHY IN THE U.K.', NULL, '', '', '2018-01-19 09:29:05', 1),
(23, 'BILL WITHERS - AIN\'T NO SUNSHINE', NULL, '', '', '2018-01-19 09:29:05', 1),
(24, 'FOO FIGHTERS~LEARN TO FLY~THERE IS NOTHING LEFT TO LOSE~1999', NULL, '', '', '2018-01-19 09:29:05', 1),
(25, 'IGGY POP~LUST FOR LIFE~LUST FOR LIFE~1977', NULL, '', '', '2018-01-19 09:29:05', 1),
(26, 'everything but the girl - missing', 5, '', '', '2018-01-19 09:29:05', 1),
(27, 'Tiromancino - ', NULL, '', '', '2018-01-19 09:29:05', 1),
(28, 'RAMONES~SHEENA IS A PUNK ROCKER~LEAVE HOME~1977', NULL, '', '', '2018-01-19 09:29:05', 1),
(29, 'PLACEBO - EVERY YOU EVERY ME', NULL, '', '', '2018-01-19 09:29:05', 1),
(30, 'PLACEBO - EVERY YOU EVERY ME', NULL, '', '', '2018-01-19 09:29:17', 1),
(31, 'JOY DIVISION - LOVE WILL TEAR US APART', NULL, '', '', '2018-01-19 09:57:59', 1),
(32, 'THE CLASH - LONDON CALLING', NULL, '', '', '2018-01-19 11:01:50', 1),
(33, 'AEROSMITH - CRAZY', NULL, '', '', '2018-01-19 15:01:42', 1),
(34, 'EXTREME - MORE THAN WORDS', NULL, '', '', '2018-01-22 12:44:23', 1),
(35, 'TEARS FOR FEARS - SOWING THE SEEDS OF LOVE', NULL, '', '', '2018-01-23 09:55:34', 1),
(36, 'ERIC CLAPTON - LAYLA', NULL, '', '', '2018-01-23 10:30:29', 1),
(37, 'POLICE - ROXANNE', NULL, '', '', '2018-01-23 11:29:57', 1),
(38, 'THE VERVE - THE DRUGS DON\'T WORK', NULL, '', '', '2018-01-23 17:26:32', 1),
(39, 'EDIE BRICKELL, NEW BOHEMIANS - WHAT I AM', NULL, '', '', '2018-01-24 14:14:01', 1),
(40, 'GORILLAZ - FEEL GOOD INC', NULL, '', '', '2018-01-25 11:09:11', 1),
(41, 'NOTHING BUT THIEVES - PARTICLES', NULL, '', '', '2018-01-25 14:08:31', 1),
(42, 'JEFFERSON AIRPLANE - WHITE RABBIT', NULL, '\'70', '', '2018-01-25 14:13:12', 1),
(43, 'bon jovi - livin on a prayer', NULL, '', '', '2018-01-27 15:19:57', 1),
(44, 'Violent Femmes - Blister in the sun', NULL, '', '', '2018-01-27 15:45:57', 1),
(45, 'Easy Star All-Stars - Let Down (feat. Toots & The Maytals)', NULL, '', '', '2018-02-06 15:48:16', 1),
(46, 'Sinéad O\'Connor - Nothing Compares 2 U', 4, '\'90', '', '2018-02-13 13:55:57', 1),
(47, 'LENNY KRAVITZ - ROCK AND ROLL IS DEAD', NULL, 'drum', '', '2018-02-21 10:58:37', 1),
(48, 'THE ROOTS - THE SEED', NULL, '', '', '2018-02-22 09:34:57', 1),
(49, 'GOTYE - SOMEBODY THAT I USED TO KNOW', 3, '', '', '2018-03-05 09:16:21', 1),
(50, 'LENNY KRAVITZ - IF YOU CAN\'T SAY NO', 3, '', '', '2018-03-05 09:16:59', 1),
(51, 'MIA MARTINI - MINUETTO', 4, 'Italian', '', '2018-03-05 09:37:01', 1),
(52, 'GEMELLI DIVERSI - UN ATTIMO ANCORA', NULL, '\'90', '', '2018-03-07 10:05:02', 1),
(53, 'Rilo Kiley - Hail To Whatever You Found In The Sunlight That Surrounds You', NULL, '', '', '2018-03-07 17:38:15', 1),
(54, 'SHIVAREE - GOODNIGHT MOON', NULL, '', '', '2018-03-08 12:33:31', 1),
(55, 'Patty Griffin - Goodbye (live)', NULL, '', '', '2018-03-09 09:15:25', 1),
(56, 'R.E.M. - Drive', NULL, '', '', '2018-03-12 17:41:11', 1),
(57, 'Focus - Hocus Pocus', NULL, '', '', '2018-03-13 09:35:07', 1),
(58, 'radio.xspf', NULL, '<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<playlist xmlns=\"http://xspf.org/ns/0/\" xmlns:vlc=\"http://www.videolan.org/vlc/playlist/ns/0/\" version=\"1\">\n	<title>Playlist</title>\n	<trackList>\n		<track>\n			<location>http://shoutcast.rtl.it:3020/</location>\n			<title>RTL best</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>0</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.rtl.it:3030/</location>\n			<title>RTL ItalianStyle</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>1</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.rtl.it:3040/</location>\n			<title>RTL Groove</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>2</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.rtl.it:3070/</location>\n			<title>RTL Lounge</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>3</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.rtl.it:3060/</location>\n			<title>RTL Radiofreccia</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>4</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.rtl.it:3030/stream/1/</location>\n			<title>Radio Zeta L’Italiana</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>5</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://wma08.fluidstream.net:4610/</location>\n			<title>Radio Kiss Kiss</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>6</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://ice07.fluidstream.net:8080/KissKiss.mp3</location>\n			<title>Radio Kiss Kiss</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>7</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://wma07.fluidstream.net:3616/;stream.nsv</location>\n			<title>Radio Kiss Kiss Italia</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>8</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://ice08.fluidstream.net/KKNapoli.aac</location>\n			<title>Radio Kiss Kiss Napoli</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>9</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://www.rds.it:8000/stream</location>\n			<title>RDS</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>10</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://radiodeejay-lh.akamaihd.net/i/RadioDeejay_Live_1@189857/master.m3u8</location>\n			<title>Radio Deejay</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>11</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icecast.unitedradio.it/r101</location>\n			<title>R101 Diretta</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>12</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icecast.unitedradio.it/Virgin.mp3</location>\n			<title>Virgin Radio</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>13</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://radiocapital-lh.akamaihd.net/i/RadioCapital_Live_1@196312/master.m3u8</location>\n			<title>Radio Capital</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>14</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/1.mp3</location>\n			<title>Rai Radio 1</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>15</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/2.mp3</location>\n			<title>Rai Radio 2</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>16</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/3.mp3</location>\n			<title>Rai Radio 3</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>17</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/4.mp3</location>\n			<title>Rai Radio 4 Light</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>18</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/5.mp3</location>\n			<title>Rai Radio 5 Classica</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>19</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it:80/9.mp3</location>\n			<title>Rai Radio 6 Teca</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>20</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it:80/10.mp3</location>\n			<title>Rai Radio 7 Live</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>21</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it:80/11.mp3</location>\n			<title>Rai Radio 8 Opera</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>22</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/6.mp3</location>\n			<title>Rai IsoRadio</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>23</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icestreaming.rai.it/7.mp3</location>\n			<title>Rai GrParlamento</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>24</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://icecast.105.net/105.mp3</location>\n			<title>Radio 105</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>25</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://edge.radiomontecarlo.net/RMC.mp3</location>\n			<title>RMC Radio Monte Carlo</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>26</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://edge.radiomontecarlo.net/MC2.mp3</location>\n			<title>RMC2 Radio Monte Carlo 2</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>27</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://radiom2o-lh.akamaihd.net/i/RadioM2o_Live_1@42518/master.m3u8</location>\n			<title>Radio m2o</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>28</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://shoutcast.radio24.it:8000/listen.pls</location>\n			<title>Radio 24</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>29</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair18.xdevel.com:8212/</location>\n			<title>Radio Marte</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>30</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://wma02.fluidstream.net:5010/</location>\n			<title>Radio Ibiza</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>31</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair11.xdevel.com:9990/</location>\n			<title>Radionorba</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>32</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair7.xdevel.com:8738/</location>\n			<title>Radionorba Music &amp; Sport</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>33</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair18.xdevel.com:8152</location>\n			<title>Radio Subasio</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>34</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair11.xdevel.com:8050</location>\n			<title>Radio Subasio +</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>35</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair11.xdevel.com:8002</location>\n			<title>Radio Amore Campania</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>36</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://nr9.newradio.it:9029</location>\n			<title>Radio Cuore</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>37</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://sr9.inmystream.info:8006</location>\n			<title>RIN Radio Italia Network</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>38</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://176.31.254.217:8030/</location>\n			<title>Radio RCS l’Onda Veronese</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>39</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://onair11.xdevel.com:8024</location>\n			<title>LifeGate Radio</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>40</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://5.63.145.172:7203/</location>\n			<title>Radio Studio Delta</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>41</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://nr5.newradio.it:8545/stream.mp3</location>\n			<title>Radio Sportiva</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>42</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://91.121.38.216:8060/</location>\n			<title>Studioradio – The Vintage Station</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>43</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://ice.studiopiu.net/rete.aac</location>\n			<title>Radio Studio Più</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>44</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://stream.rcdc.it:8000/</location>\n			<title>Radio Città Del Capo</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>45</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://comodino.org:8001/rcf.ogg</location>\n			<title>Radio Città Fujiko</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>46</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://stream-dc1.radioparadise.com:80/aac-128</location>\n			<title>Radio Paradise - DC1</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>47</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://stream-tx3.radioparadise.com:80/aac-128</location>\n			<title>Radio Paradise - TX3</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>48</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://stream-eu1.radioparadise.com:80/aac-128</location>\n			<title>Radiu Paradise - EU1</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>49</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>\n		<track>\n			<location>http://stream-uk1.radioparadise.com:80/aac-128</location>\n			<title>Radiu Paradise - UK1</title>\n			<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n				<vlc:id>50</vlc:id>\n				<vlc:option>network-caching=1000</vlc:option>\n				<vlc:option>network-caching=1000</vlc:option>\n			</extension>\n		</track>		\n	</trackList>\n	<extension application=\"http://www.videolan.org/vlc/playlist/0\">\n			<vlc:item tid=\"0\"/>\n			<vlc:item tid=\"1\"/>\n			<vlc:item tid=\"2\"/>\n			<vlc:item tid=\"3\"/>\n			<vlc:item tid=\"4\"/>\n			<vlc:item tid=\"5\"/>\n			<vlc:item tid=\"6\"/>\n			<vlc:item tid=\"7\"/>\n			<vlc:item tid=\"8\"/>\n			<vlc:item tid=\"9\"/>\n			<vlc:item tid=\"10\"/>\n			<vlc:item tid=\"11\"/>\n			<vlc:item tid=\"12\"/>\n			<vlc:item tid=\"13\"/>\n			<vlc:item tid=\"14\"/>\n			<vlc:item tid=\"15\"/>\n			<vlc:item tid=\"16\"/>\n			<vlc:item tid=\"17\"/>\n			<vlc:item tid=\"18\"/>\n			<vlc:item tid=\"19\"/>\n			<vlc:item tid=\"20\"/>\n			<vlc:item tid=\"21\"/>\n			<vlc:item tid=\"22\"/>\n			<vlc:item tid=\"23\"/>\n			<vlc:item tid=\"24\"/>\n			<vlc:item tid=\"25\"/>\n			<vlc:item tid=\"26\"/>\n			<vlc:item tid=\"27\"/>\n			<vlc:item tid=\"28\"/>\n			<vlc:item tid=\"29\"/>\n			<vlc:item tid=\"30\"/>\n			<vlc:item tid=\"31\"/>\n			<vlc:item tid=\"32\"/>\n			<vlc:item tid=\"33\"/>\n			<vlc:item tid=\"34\"/>\n			<vlc:item tid=\"35\"/>\n			<vlc:item tid=\"36\"/>\n			<vlc:item tid=\"37\"/>\n			<vlc:item tid=\"38\"/>\n			<vlc:item tid=\"39\"/>\n			<vlc:item tid=\"40\"/>\n			<vlc:item tid=\"41\"/>\n			<vlc:item tid=\"42\"/>\n			<vlc:item tid=\"43\"/>\n			<vlc:item tid=\"44\"/>\n			<vlc:item tid=\"45\"/>\n			<vlc:item tid=\"46\"/>\n			<vlc:item tid=\"47\"/>\n			<vlc:item tid=\"48\"/>\n			<vlc:item tid=\"49\"/>\n			<vlc:item tid=\"50\"/>			\n	</extension>\n</playlist>\n\n', '', '2018-03-14 09:03:38', 1),
(59, 'Bruce Springsteen - Streets of Philadelphia', NULL, '', '', '2018-03-19 10:49:04', 1),
(60, 'THE CONNELLS - \'74-\'75', NULL, '', '', '2018-03-20 09:09:44', 1),
(61, 'PROCOL HARUM - A WHITER SHADE OF PALE', NULL, '\'60', '', '2018-03-20 09:35:52', 1),
(62, 'crash test dummies - mmm', NULL, '', '', '2018-03-20 10:01:33', 1),
(63, 'Florence + The Machine - Heartlines', NULL, '', '', '2018-03-22 15:13:47', 1),
(64, 'TEARS FOR FEARS, OLETA ADAMS - WOMAN IN CHAINS', NULL, '', '', '2018-04-03 16:21:34', 1),
(65, 'Rosie Carney - WINTER', NULL, '', '', '2018-04-06 14:25:25', 1),
(66, 'MADONNA - PAPA DON\'T PREACH', NULL, '', '', '2018-04-09 09:07:48', 1),
(67, 'QUEEN - SOMEBODY TO LOVE', NULL, '', '', '2018-04-09 09:12:02', 1),
(68, 'Antonio Vivaldi - The 4 Seasons: Summer', NULL, '', '', '2018-04-09 11:36:31', 1),
(69, 'The Decemberists - Carolina Low', NULL, '', '', '2018-04-09 12:25:46', 1),
(70, 'PATTY SMITH - Because The Night', NULL, '', '', '2018-04-10 10:55:24', 1),
(71, 'NADA - AMORE DISPERATO', NULL, '', '', '2018-04-11 11:50:15', 1),
(72, 'John Coltrane - Theme For Ernie', NULL, '', '', '2018-04-11 14:22:21', 1),
(73, 'Stone Temple Pilots - Big Empty', NULL, '', '', '2018-04-11 15:01:05', 1),
(74, 'R.E.M. - LOSING MY RELIGION', NULL, '', '', '2018-04-12 09:08:52', 1),
(75, 'Chuck Berry - No Particular Place To Go', NULL, '', '', '2018-04-12 10:29:21', 1),
(76, 'MADONNA - WHO\'S THAT GIRL', NULL, '', '', '2018-04-12 10:53:42', 1),
(77, 'CULTURE CLUB, BOY GEORGE - DO YOU REALLY WANT TO HURT ME', NULL, '', '', '2018-04-12 14:14:22', 1),
(78, 'everything but the girl - missing', NULL, '', '', '2018-04-12 15:58:36', 1),
(79, 'Cyndi Lauper - Time After Time', NULL, '', '', '2018-04-13 11:42:38', 1),
(80, 'Bill Withers - Ain\'t No Sunshine', NULL, '', '', '2018-04-23 14:12:16', 1),
(81, 'Roy Rogers - I\'m With You', NULL, '', '', '2018-04-27 09:07:42', 1),
(82, 'Agnes Obel - Riverside', NULL, '', '', '2018-05-09 10:54:11', 1),
(83, 'Agnes Obel - Riverside', NULL, '', '', '2018-05-09 11:45:38', 1),
(84, 'Ray LaMontagne - Be Here Now', NULL, '', '', '2018-05-11 13:57:45', 1),
(85, 'Steely Dan - Do It Again', NULL, '', '', '2018-05-14 09:06:26', 1),
(86, 'Vienna Teng - Augustine', NULL, '', '', '2018-05-17 10:15:42', 1),
(87, 'Breeders - 02 - cannonball', NULL, '', '', '2018-05-21 10:57:13', 1),
(88, 'LORDE - ROYALS', NULL, '', '', '2018-05-22 10:16:42', 1),
(89, 'The Drums - Let\'s Go Surfing', NULL, '', '', '2018-05-23 17:51:10', 1),
(90, 'The Strokes - Last Nite', NULL, '', '', '2018-05-23 17:53:52', 1),
(91, 'A-Punk - Vampire Weekend', NULL, '', '', '2018-05-24 09:27:38', 1),
(92, 'Joy Division - She\'s Lost Control', NULL, '', 'https://www.youtube.com/watch?v=ZGMDBppWBOo', '2018-05-24 11:43:01', 1),
(93, 'Death Cab For Cutie - I Will Follow You Into The Dark', NULL, '', '', '2018-05-24 13:51:49', 1),
(94, 'Hysteria - Muse', NULL, '', '', '2018-05-24 15:24:31', 1),
(95, 'Time Is Running Out - Muse', NULL, '', '', '2018-05-24 16:22:20', 1),
(96, 'nothing else matter - metallica', NULL, '', '', '2018-05-25 14:06:42', 1),
(97, 'Santana - Samba Pa Ti', NULL, '', '', '2018-06-12 12:19:12', 1),
(98, 'mario venuti - fortuna', NULL, '', '', '2018-07-14 12:53:52', 1),
(99, 'alicia keys - you don\'t know my name', NULL, '', '', '2018-07-20 09:20:15', 1),
(100, 'cure - boys don\'t cry', NULL, '', '', '2018-07-20 12:38:07', 1),
(101, 'Belly - Feed The Tree', NULL, '', '', '2018-07-23 09:01:06', 1),
(102, 'BLACK SABBATH - IRON MAN', NULL, '', '', '2018-07-30 08:42:37', 1),
(103, 'WEEZER - BEVERLY HILLS', NULL, '', '', '2018-07-30 09:19:20', 1),
(104, 'FATBOY SLIM - RIGHT HERE, RIGHT NOW', NULL, '', '', '2018-07-30 10:19:55', 1),
(105, 'Madonna - Like A Prayer', NULL, '', '', '2018-07-31 15:34:30', 1),
(106, 'The Sundays - Here\'s Where The Story Ends', NULL, '', '', '2018-08-01 08:54:34', 1),
(107, 'The Audreys - Long Ride', NULL, '', '', '2018-08-01 13:58:00', 1),
(108, 'Focus - Hocus Pocus', NULL, '', '', '2018-08-03 16:05:22', 1),
(109, 'The Dandy Warhols - Bohemian Like You', NULL, '', '', '2018-08-06 09:00:54', 1),
(110, 'Miles Davis - \'Round Midnight', NULL, '', '', '2018-08-06 10:28:45', 1),
(111, 'Cloud Cult - When Water Comes to Life', NULL, '', '', '2018-08-08 15:52:47', 1),
(112, 'Sivert Høyem - Prisoner of the Road', NULL, '', '', '2018-08-27 07:23:10', 1),
(113, 'The Decemberists - Carolina Low', NULL, '', '', '2018-08-28 12:04:09', 1),
(114, 'The Decemberists - Till the Water Is All Long Gone', NULL, '', '', '2018-08-28 12:09:13', 1),
(115, 'LANA DEL REY - West Coast', NULL, '', '', '2018-09-05 09:46:24', 1),
(116, 'Frida Snell - Bullet With Butterfly Wings', NULL, '', '', '2018-09-11 07:44:58', 1),
(117, 'Nick Drake - Cello Song', NULL, '', '', '2018-09-11 08:35:15', 1),
(118, 'Heather Nova - Island', NULL, '', '', '2018-09-11 13:03:21', 1),
(119, 'Everything But The Girl - Missing', NULL, '', 'https://www.youtube.com/watch?v=Q4sPkS8b62Q\r\n', '2018-09-13 14:42:33', 1),
(120, 'ub40 - rat in my kitchen', NULL, '', '', '2018-09-26 12:44:47', 1),
(121, 'UB40 - Red Red Wine', NULL, '', '', '2018-09-26 12:44:58', 1),
(122, 'UB40 - Kingstone town', NULL, '', '', '2018-09-26 12:51:05', 1),
(123, 'Ramones - Do You Wanna Dance?', NULL, '', '', '2018-09-27 07:32:07', 1),
(124, 'Finley Quaye - Even after all', NULL, '', 'https://www.youtube.com/watch?v=214cQIpcCIc', '2018-09-28 14:01:29', 1),
(125, 'samuele bersani - spaccacuore\r\n', NULL, '', '', '2018-10-01 13:47:28', 1),
(126, 'Ben Harper - When It\'s Good', NULL, '', '', '2018-10-03 08:00:57', 1),
(127, 'Family Of The Year - Hero', NULL, '', '', '2018-10-03 15:13:53', 1),
(128, 'BOBBY MCFERRIN - DON\'T WORRY, BE HAPPY', NULL, '', '', '2018-10-09 07:11:58', 1),
(129, 'NINE MILLION BICYCLES', 2, '', 'https://www.youtube.com/watch?v=eHQG6-DojVw', '2018-10-09 07:16:47', 1),
(130, 'What I am', 3, '', 'https://www.youtube.com/watch?v=tDl3bdE3YQA', '2018-10-09 08:38:15', 1),
(131, 'Francesco De Gregori - RIMMEL', 0, '', 'https://www.youtube.com/watch?v=Ydo-yfPze30', '2018-10-09 10:39:01', 1),
(132, 'Marilyn Manson - Sweet Dreams (Are Made Of This)', NULL, '', '', '2018-10-09 20:12:51', 1),
(133, 'Sunken - Swoon', NULL, '', '', '2018-10-10 07:07:44', 1),
(134, 'FIRST AID KIT - Tender Offerings', NULL, '', '', '2018-10-10 09:03:27', 1),
(135, 'Snowbird - Heart Of The Woods', NULL, '', '', '2018-10-12 12:39:35', 1),
(136, 'SERGIO CAMMARIERE - MALGRADO POI', NULL, '', '', '2018-10-15 07:05:46', 1),
(137, 'Bat For Lashes - All Your Gold', 0, '', '', '2018-10-15 08:55:10', 1),
(138, 'Lamb - Gorecki', 0, '', 'https://www.youtube.com/watch?v=tSRYvYN1ayw', '2018-10-15 09:34:54', 1),
(139, 'Given To Fly', 0, '', 'https://www.youtube.com/watch?v=satY_ofTNo4', '2018-10-16 07:34:01', 1),
(140, 'Rapture', 0, '', 'https://www.youtube.com/watch?v=pHCdS7O248g', '2018-10-16 09:57:43', 1),
(141, 'The Doors - People Are Strange', 0, '', 'https://www.youtube.com/watch?v=GJY8jJkDoMY', '2018-10-16 09:58:06', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `best_songs`
--
ALTER TABLE `best_songs`
  ADD PRIMARY KEY (`id_best_songs`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `best_songs`
--
ALTER TABLE `best_songs`
  MODIFY `id_best_songs` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
